import PageHeader from "../components/PageHeader";
import { Container, Divider } from "@mui/material";
import Grid from "@mui/material/Grid";
import { Typography } from "@mui/material";

const AboutPage = () => {
	return (
		<Container>
			<PageHeader title="About Page" subtitle="On this page you can find explanations about the application" />
			<Grid spacing={2}>
				<Grid item md={8} xs={12} alignSelf="center">
					<Typography sx={{ fontSize: 14 }}>
						This is my senior react app project, developed using React,redux,material ui and more libraries. in this app you can see Cards created by
						users ,you can create users, you can add like on cards, you can delete and edit your own cards and more features.
						<Divider sx={{ my: 2 }}> Below you can see card example</Divider>
					</Typography>
				</Grid>
				<Grid item md={4} xs={12} alignSelf="center" sx={{ display: { md: "flex", s: "flex", xs: "flex" }, justifyContent: "center" }}>
					<img src="/assets/images/card.jpg" alt="card" width="80%" style={{ maxWidth: "400px" }} />
				</Grid>
			</Grid>
		</Container>
	);
};

export default AboutPage;
