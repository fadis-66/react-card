const initialSignupForm = {
	first: "",
	last: "",
	middle: "",
	email: "",
	phone: "",
	password: "",
	url: "",
	alt: "",
	state: "",
	country: "",
	city: "",
	street: "",
	houseNumber: 0,
	zip: 0,
	isBusiness: false,
};

export const initialEditForm = {
	first: "",
	last: "",
	middle: "",
	email: "",
	phone: "",
	url: "",
	alt: "",
	state: "",
	country: "",
	city: "",
	street: "",
	houseNumber: 0,
	zip: 0,
	isBusiness: false,
};

export default initialSignupForm;
