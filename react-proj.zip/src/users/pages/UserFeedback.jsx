import Error from "../../components/Error";
import Spinner from "../../components/Spinner";
import { Typography } from "@mui/material";
import User from "./../component/User";

const UserFeedback = ({ isPending, error, user }) => {
	if (isPending) return <Spinner />;
	if (error) return <Error errorMessage={error} />;
	if (!user) return <Typography>Oops... it seems there are no user to display</Typography>;
	else return <User user={user}></User>;
};

export default UserFeedback;
