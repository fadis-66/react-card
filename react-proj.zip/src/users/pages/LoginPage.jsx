import ROUTES from "../../routes/routesModel";
import { Navigate } from "react-router-dom";
import { useUser } from "../providers/UserProvider";
import useUsers from "../hooks/useUsers";
import useForm from "../../forms/hooks/useForms";
import initialLoginForm from "../helpers/initialForms/initialLoginForm";
import loginSchema from "../models/joi-schema/loginSchema";
import Form from "../../forms/components/Form";
import Input from "../../forms/components/Input";
import Grid from "@mui/material/Grid";
import { Link } from "react-router-dom";
import { Box } from "@mui/material";
import CssBaseline from "@mui/material/CssBaseline";
import { useTheme } from "../../providers/ThemeProvider";
import { Typography } from "@mui/material";

const LoginPage = () => {
	const { user } = useUser();
	const { isDark } = useTheme();

	const { handleLogin } = useUsers();

	const { value, ...rest } = useForm(initialLoginForm, loginSchema, handleLogin);

	if (user) return <Navigate to={ROUTES.CARDS} />;

	return (
		<Grid container component="main" sx={{ display: "flex", justifyContent: "center", height: "50vh" }}>
			<CssBaseline />

			<Grid
				sx={{
					backgroundImage: "url(https://source.unsplash.com/random?landscape)",
					backgroundRepeat: "no-repeat",
					// backgroundColor: (t) => (t.palette.mode === "light" ? t.palette.grey[50] : t.palette.grey[900]),
					backgroundSize: "cover",
					backgroundPosition: "center",
					height: "300px",
					width: "300px",
					mt: "50px",
				}}
			/>
			<Box mt={2} justifyContent="center" fontSize={15}>
				<Form
					onSubmit={rest.onSubmit}
					onReset={rest.handleReset}
					onChange={rest.validateForm}
					title="Login"
					styles={{ maxWidth: "450px" }}
					to={ROUTES.CARDS}
				>
					<Input label={"Email"} name={"email"} type={"email"} data={value.data} error={value.errors.email} handleChange={rest.handleChange} />
					<Input
						label={"Password"}
						name={"password"}
						type={"password"}
						data={value.data}
						error={value.errors.password}
						handleChange={rest.handleChange}
					/>
				</Form>
				<Grid container pl={3}>
					<Grid item>
						<Link to={ROUTES.SIGNUP} variant="body2">
							<Typography color={isDark ? "white" : "black"}>Don't have account? Sign Up </Typography>
						</Link>
					</Grid>
				</Grid>
			</Box>
		</Grid>
	);
};

export default LoginPage;
