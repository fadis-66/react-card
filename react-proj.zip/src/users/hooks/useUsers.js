import { useCallback, useMemo, useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useUser } from "../providers/UserProvider";
import useAxios from "../../hooks/useAxios";
import { login, signup, editUser } from "../services/usersApiService";
import { getUser, getUserId, removeToken, setTokenInLocalStorage } from "../services/localStorageService";
import ROUTES from "../../routes/routesModel";
import normalizeUser from "./../../users/helpers/normalization/normalizeUser";
import { useSnackbar } from "../../providers/SnackbarProvider";

const useUsers = () => {
	const [users, setUsers] = useState(null);
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState(null);
	const snack = useSnackbar();
	const [searchParams] = useSearchParams();
	const [filteredUsers, setFilteredUsers] = useState(null);
	const [query, setQuery] = useState("");

	const navigate = useNavigate();
	const { user, setUser, setToken } = useUser();

	useAxios();

	useEffect(() => {
		setQuery({
			q: searchParams.get("q") ?? "",
			isBusiness: searchParams.get("isBusiness"),
		});
	}, [searchParams]);

	useEffect(() => {
		if (users) {
			const filtered = users.filter(
				(u) => (u.name.first.includes(query.q) || u.name.last.includes(query.q)) && (!query.isBusiness || u.isBusiness === String(u.isBusiness))
			);
			setFilteredUsers(filtered);
		}
	}, [query, users]);

	const requestStatus = useCallback(
		(loading, errorMessage, users, user = null) => {
			setLoading(loading);
			setError(errorMessage);
			setUsers(users);
			setUser(user);
		},
		[setUser]
	);

	const handleLogin = useCallback(
		async (user) => {
			try {
				const token = await login(user);
				setTokenInLocalStorage(token);
				setToken(token);
				const userFromLocalStorage = getUser();
				requestStatus(false, null, null, userFromLocalStorage);
				snack("success", "you have been successfully logged in to your user ");
				navigate(ROUTES.CARDS);
			} catch (error) {
				requestStatus(false, error.message, null);
			}
		},
		[navigate, requestStatus, setToken]
	);

	const handleSignup = useCallback(
		async (user) => {
			try {
				const normalizedUser = normalizeUser(user);
				await signup(normalizedUser);
				await handleLogin({ email: user.email, password: user.password });
			} catch (error) {
				requestStatus(false, error.message, null);
			}
		},
		[requestStatus, handleLogin]
	);

	const handleUpdateUser = useCallback(async (user, id) => {
		try {
			setLoading(true);
			const userUpdate = await editUser(user, id);
			requestStatus(false, null, null, userUpdate);
			snack("success", "The User has been successfully updated");
			navigate(ROUTES.CARDS);
		} catch (error) {
			requestStatus(false, error.message, null, null);
		}
	}, []);

	const handleLogout = useCallback(() => {
		removeToken();
		setToken(null);
		setUser(null);
		snack("warning", "The User has been Logout successfully ");
		navigate(ROUTES.LOGIN);
	}, [setUser, setToken]);

	const value = useMemo(
		() => ({
			users,
			user,
			loading,
			error,
			filteredUsers,
		}),
		[users, user, loading, error, filteredUsers]
	);

	return {
		...value,
		handleLogin,
		handleLogout,
		handleSignup,
		handleUpdateUser,
	};
};

export default useUsers;
