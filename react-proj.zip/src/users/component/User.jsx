import { Card, CardActionArea } from "@mui/material";
import UserHead from "./UserHead";
import UserBody from "./UserBody";

const UserComponent = ({ user }) => {
	return (
		<Card sx={{ minWidth: 280, maxWidth: 350 }}>
			<CardActionArea>
				<UserHead image={user.image} />
				<UserBody card={user} />
			</CardActionArea>
		</Card>
	);
};

export default UserComponent;
