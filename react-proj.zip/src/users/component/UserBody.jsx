import { Box, CardContent, CardHeader, Divider, Typography } from "@mui/material";
import UserComponent from "./User";

const UserBody = ({ user }) => {
	const {
		first,

		last,
		phone,
		email,
		isBusiness,
		address: { state, country, city, street, houseNumber, zip },
	} = user;

	return (
		<CardContent>
			<CardHeader sx={{ p: 0, md: 1 }} />
			<CardHeader title={first} subheader={last} sx={{ p: 0, md: 1 }} />
			<Divider />
			<Box mt={1}>
				<Typography variant="body2" color="text.secondary">
					<Typography variant="subtitle2" component="strong">
						Phone:{" "}
					</Typography>
					{phone}
				</Typography>

				<Typography variant="body2" color="text.secondary">
					<Typography variant="subtitle2" component="strong">
						Address:{" "}
					</Typography>
					{country} {state} {city} {street} {houseNumber} {zip}
				</Typography>

				<Typography variant="body2" color="text.secondary">
					<Typography variant="subtitle2" component="strong">
						email :{" "}
					</Typography>
					{email}
				</Typography>
				<Typography variant="body2" color="text.secondary">
					<Typography variant="subtitle2" component="strong">
						is business :{" "}
					</Typography>
					{isBusiness}
				</Typography>
			</Box>
		</CardContent>
	);
};

export default UserBody;
