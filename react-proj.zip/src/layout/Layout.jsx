import { node } from "prop-types";
import { Box } from "@mui/material";
import Footer from "./footer/Footer";
import Header from "./header/Header";
import Main from "./main/Main";

const Layout = ({ children }) => {
	return (
		<Box>
			<Header />
			<Main>{children}</Main>
			<Footer />
		</Box>
	);
};

Layout.propTypes = {
	children: node.isRequired,
};

export default Layout;
