import NavBar from "./TopNavBar/NavBar";

const Header = () => <NavBar />;

export default Header;
