import Typography from "@mui/material/Typography";
import NavBarLink from "../../../../routes/NavBarLink";
import ROUTES from "../../../../routes/routesModel";
import { useTheme } from "./../../../../providers/ThemeProvider";

const Logo = () => {
	const { isDark } = useTheme();

	return (
		<NavBarLink to={ROUTES.CARDS}>
			<Typography
				variant="h4"
				sx={{
					display: { xs: "none", md: "inline-flex" },
					marginRight: 2,
					fontFamily: "fantasy",
					color: isDark ? "white" : "black",
				}}
			>
				BCard
			</Typography>
		</NavBarLink>
	);
};
export default Logo;
