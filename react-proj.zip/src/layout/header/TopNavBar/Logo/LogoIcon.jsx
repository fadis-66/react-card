import IconButton from "@mui/material/IconButton";
import Avatar from "@mui/material/Avatar";
import Tooltip from "@mui/material/Tooltip";
import { useMenu } from "../menu/MenuProviderLeft";

const LogoIcon = () => {
	const setOpen = useMenu();

	return (
		<Tooltip title="Open Menu">
			<IconButton
				sx={{
					display: { xs: "inline-flex", md: "none" },
					size: "large",
					edge: "start",
					color: "inherit",
				}}
				onClick={() => setOpen(true)}
			>
				<Avatar alt="me" src="/assets/images/business-card.png"></Avatar>
			</IconButton>
		</Tooltip>
	);
};

export default LogoIcon;
