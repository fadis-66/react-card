import { Box } from "@mui/material";
import Logo from "../Logo/Logo";
import LogoIcon from "../Logo/LogoIcon";
import NavItem from "../../../../routes/NavItem";
import ROUTES from "../../../../routes/routesModel";
import { useUser } from "../../../../users/providers/UserProvider";
import MenuBarLeft from "../right-navigation/MenuBarLeft";
import { useState } from "react";
import { useTheme } from "./../../../../providers/ThemeProvider";

const LeftNavBar = () => {
	const { user } = useUser();
	const [anchorEl, setAnchor] = useState(null);
	const { isDark } = useTheme();

	const closeMenu = () => {
		setAnchor(null);

		console.log("you closed the menu");
	};

	return (
		<>
			<Box>
				<Logo />
				<LogoIcon />
				<Box sx={{ display: { xs: "none", md: "inline-flex" } }}>
					<NavItem color={isDark ? "white" : "black"} label="About" to={ROUTES.ABOUT}></NavItem>
					{user && (
						<>
							<NavItem color={isDark ? "white" : "black"} label="Fav Cards" to={ROUTES.FAV_CARDS}></NavItem>
						</>
					)}
					{user && user.isBusiness && (
						<>
							<NavItem color={isDark ? "white" : "black"} label="My Cards" to={ROUTES.MY_CARDS}></NavItem>
						</>
					)}

					{user && user.isAdmin && <NavItem color={isDark ? "white" : "black"} label="Sandbox 🧃" to={ROUTES.SANDBOX}></NavItem>}
				</Box>
			</Box>
			<MenuBarLeft isMenuOpen={Boolean(anchorEl)} anchorEl={anchorEl} onCloseMenu={closeMenu} />
		</>
	);
};
export default LeftNavBar;
