import { Box } from "@mui/material";
import NavItem from "../../../../routes/NavItem";
import ROUTES from "../../../../routes/routesModel";
import { useTheme } from "../../../../providers/ThemeProvider";

const NotLogged = () => {
	const { isDark } = useTheme();

	return (
		<Box>
			<NavItem color={isDark ? "white" : "black"} label="Sign Up" to={ROUTES.SIGNUP} />
			<NavItem color={isDark ? "white" : "black"} label="Log In" to={ROUTES.LOGIN} />
		</Box>
	);
};

export default NotLogged;
