import MuiMenu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import { Box, Button, Typography } from "@mui/material";
import NavBarLink from "../../../../routes/NavBarLink";
import ROUTES from "../../../../routes/routesModel";
import { useUser } from "../../../../users/providers/UserProvider";
import useUsers from "../../../../users/hooks/useUsers.js";
import { useTheme } from "../../../../providers/ThemeProvider.jsx";

const MenuBar = ({ isMenuOpen, anchorEl, onCloseMenu }) => {
	const { user } = useUser();
	const { handleLogout } = useUsers();
	const { isDark } = useTheme();

	const onLogout = () => {
		handleLogout();
		onCloseMenu();
	};

	return (
		<MuiMenu
			open={isMenuOpen}
			onClose={onCloseMenu}
			anchorEl={anchorEl}
			anchorOrigin={{
				vertical: "top",
				horizontal: "right",
			}}
			keepMounted
			transformOrigin={{
				vertical: "top",
				horizontal: "right",
			}}
		>
			{user && (
				<Box>
					<NavBarLink to={ROUTES.EDIT_USER}>
						<MenuItem onClick={onCloseMenu}>
							<Typography color={isDark ? "white" : "black"}>Edit Accouunt</Typography>
						</MenuItem>
					</NavBarLink>
					<NavBarLink to={ROUTES.LOGIN}>
						<MenuItem onClick={onLogout}>
							<Typography color={isDark ? "white" : "black"}>Logout</Typography>
						</MenuItem>
					</NavBarLink>
				</Box>
			)}
			<NavBarLink to={ROUTES.ABOUT}>
				<Button color="inherit">
					<Typography color={isDark ? "white" : "black"}>About</Typography>
				</Button>
			</NavBarLink>

			{!user && (
				<Box>
					<NavBarLink to={ROUTES.LOGIN}>
						<MenuItem sx={{ display: { xs: "block", md: "none" } }} onClick={onCloseMenu}>
							Login
						</MenuItem>
					</NavBarLink>

					<NavBarLink to={ROUTES.SIGNUP}>
						<MenuItem sx={{ display: { xs: "block", md: "none" } }} onClick={onCloseMenu}>
							SignUp
						</MenuItem>
					</NavBarLink>
				</Box>
			)}
		</MuiMenu>
	);
};

export default MenuBar;
