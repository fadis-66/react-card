import MuiMenu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import { Box } from "@mui/material";
import NavBarLink from "../../../../routes/NavBarLink";
import ROUTES from "../../../../routes/routesModel";
import { useUser } from "../../../../users/providers/UserProvider";
import { useTheme } from "./../../../../providers/ThemeProvider";

const MenuBarLeft = ({ isMenuOpen, anchorEl, onCloseMenu }) => {
	const { user } = useUser();
	const { isDark } = useTheme();

	return (
		<MuiMenu
			open={isMenuOpen}
			onClose={onCloseMenu}
			anchorEl={anchorEl}
			anchorOrigin={{
				vertical: "top",
				horizontal: "left",
			}}
			keepMounted
			transformOrigin={{
				vertical: "top",
				horizontal: "left",
			}}
		>
			{user && (
				<Box>
					<NavBarLink to={ROUTES.CARDS}>
						<MenuItem onClick={onCloseMenu}>Home</MenuItem>
					</NavBarLink>

					<NavBarLink to={ROUTES.FAV_CARDS}>
						<MenuItem onClick={onCloseMenu}>Favorite Card</MenuItem>
					</NavBarLink>
					<NavBarLink to={ROUTES.MY_CARDS}>
						<MenuItem onClick={onCloseMenu}>My Cards</MenuItem>
					</NavBarLink>
					<NavBarLink to={ROUTES.ABOUT}>
						<MenuItem onClick={onCloseMenu}>About</MenuItem>
					</NavBarLink>
				</Box>
			)}

			{!user && (
				<Box>
					<NavBarLink to={ROUTES.CARDS}>
						<MenuItem sx={{ color: isDark ? "white" : "black", display: { xs: "block", md: "none" } }} onClick={onCloseMenu}>
							HOME
						</MenuItem>
					</NavBarLink>

					<NavBarLink to={ROUTES.ABOUT}>
						<MenuItem sx={{ color: isDark ? "white" : "black", display: { xs: "block", md: "none" } }} onClick={onCloseMenu}>
							ABOUT
						</MenuItem>
					</NavBarLink>
				</Box>
			)}
		</MuiMenu>
	);
};

export default MenuBarLeft;
