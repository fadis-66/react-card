import { node } from "prop-types";
import { Box } from "@mui/material";
import { useTheme } from "./../../providers/ThemeProvider";

const Main = ({ children }) => {
	const { isDark } = useTheme();

	return <Box sx={{ minHeight: "90vh", backgroundColor: isDark ? "#454545" : "#b8e0ff" }}>{children}</Box>;
};

Main.prototype = {
	children: node.isRequired,
};

export default Main;
