import { Paper, BottomNavigation, BottomNavigationAction, Typography } from "@mui/material";
import InfoIcon from "@mui/icons-material/Info";
import FavoriteIcon from "@mui/icons-material/Favorite";
import PortraitIcon from "@mui/icons-material/Portrait";
import { useNavigate } from "react-router-dom";
import ROUTES from "../../routes/routesModel";
import { useUser } from "../../users/providers/UserProvider";
import { useTheme } from "./../../providers/ThemeProvider";
const Footer = () => {
	const navigate = useNavigate();
	const navigateTo = (to) => navigate(to);
	const { user } = useUser();
	const { isDark } = useTheme();

	return (
		<Paper sx={{ backgroundColor: isDark ? "#0B0B0B" : "#1976D2", position: "sticky", bottom: 0, left: 0, right: 0 }} elevation={3}>
			<BottomNavigation>
				<BottomNavigationAction
					onClick={() => navigateTo(ROUTES.ABOUT)}
					label="About"
					icon={
						<>
							<InfoIcon fontSize="large" />
							<Typography>About</Typography>
						</>
					}
				/>
				{user && (
					<BottomNavigationAction
						onClick={() => navigateTo(ROUTES.FAV_CARDS)}
						label="Favorites"
						icon={
							<>
								<FavoriteIcon fontSize="large" />
								<Typography>Favorites</Typography>
							</>
						}
					/>
				)}
				{user && user.isBusiness && (
					<BottomNavigationAction
						onClick={() => navigateTo(ROUTES.MY_CARDS)}
						label="My Cards"
						icon={
							<>
								<PortraitIcon fontSize="large" />
								<Typography>My Cards</Typography>
							</>
						}
					/>
				)}
			</BottomNavigation>
		</Paper>
	);
};

export default Footer;
