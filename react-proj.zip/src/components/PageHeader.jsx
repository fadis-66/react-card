import { string } from "prop-types";
import { Box, Divider, Typography } from "@mui/material";
import { useTheme } from "./../providers/ThemeProvider";

const PageHeader = ({ title, subtitle }) => {
	const { isDark } = useTheme();

	return (
		<Box pt={2}>
			<Typography variant="h2" color={isDark ? "white" : "black"} component="h1">
				{title}
			</Typography>
			<Typography variant="h5" color={isDark ? "white" : "black"} component="h2">
				{subtitle}
			</Typography>
			<Divider sx={{ my: 2 }}></Divider>
		</Box>
	);
};

PageHeader.propTypes = {
	title: string.isRequired,
	subtitle: string.isRequired,
};
export default PageHeader;
