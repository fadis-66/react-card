import { useParams } from "react-router-dom";
import Container from "@mui/material/Container";
import PageHeader from "../../components/PageHeader";
import useCards from "../hooks/useCards";
import { useEffect } from "react";
import { Box } from "@mui/material";
import CardFeedback from "./../components/CardFeedback";
import { Typography } from "@mui/material";
import "../../index.css";
import { useTheme } from "./../../providers/ThemeProvider";

const CardDetailsPage = () => {
	const { id } = useParams();
	const {
		value: { card, isPending, error },
		handleGetCard,
	} = useCards();
	const { isDark } = useTheme();

	useEffect(() => {
		handleGetCard(id);
	}, [id]);

	if (card) {
		var Address = `${card.address.country}+${card.address.city}+${card.address.street}+${card.address.houseNumber}`;
		return (
			<Container maxWidth="lg">
				<PageHeader title="Business Details" subtitle="Here you can find all the information about the business you are looking for."></PageHeader>
				<Typography sx={{ color: isDark ? "white" : "black", fontSize: 25 }}>
					Details on card : {card?.title} - {card?.subtitle}
				</Typography>

				<Box sx={{ justifyContent: "center", gap: "10px", flexWrap: "wrap", display: "flex", alignItems: "center", m: 2, borderRadius: 10 }}>
					<div className="boxShadow" style={{ height: "100%" }}>
						<CardFeedback isPending={isPending} error={error} cards={card} />
					</div>

					<Box sx={{ pl: "20px" }}>
						<iframe
							title="GoogleMap"
							style={{ maxWidth: "100%", borderRadius: 10, borderStyle: "inherit" }}
							width="400"
							height="400"
							className="boxShadow"
							loading="lazy"
							referrerPolicy="no-referrer-when-downgrade"
							src={`https://www.google.com/maps/embed/v1/place?key=AIzaSyD0mVcLletdjdkce5W7BmAls5tbdN73cDQ&q=${Address}`}
						/>
					</Box>
				</Box>
			</Container>
		);
	}
};

export default CardDetailsPage;
