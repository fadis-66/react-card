import Error from "../../components/Error";
import Spinner from "../../components/Spinner";
import { Typography } from "@mui/material";
import Card from "./card/Card";
import { arrayOf, bool, func, string } from "prop-types";
import cardType from "../models/types/cardType";

const CardFeedback = ({ isPending, error, cards, onDeleteCard, onLike }) => {
	if (isPending) return <Spinner />;
	if (error) return <Error errorMessage={error} />;
	if (!cards) return <Typography>Oops... it seems there are no business cards to display</Typography>;
	else return <Card card={cards} onDeleteCard={onDeleteCard} onLike={onLike} />;
};

CardFeedback.propTypes = {
	isPending: bool.isRequired,
	error: string,
	cards: arrayOf(cardType),
	onLike: func.isRequired,
};

CardFeedback.defaultProps = {
	onLike: async () => {},
};

export default CardFeedback;
