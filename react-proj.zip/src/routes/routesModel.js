const ROUTES = {
	ROOT: "/",
	ABOUT: "/about",
	CARDS: "/cards",
	MY_CARDS: "/my-cards",
	FAV_CARDS: "/fav-cards",
	CARD_DETAILS: "/card-info",
	SANDBOX: "/sandbox",
	LOGIN: "/login",
	SIGNUP: "/signup",
	EDIT_USER: "/edit-user",
	CREATE_CARD: "/create-card",
	EDIT_CARD: "/edit-card",
};

export default ROUTES;
